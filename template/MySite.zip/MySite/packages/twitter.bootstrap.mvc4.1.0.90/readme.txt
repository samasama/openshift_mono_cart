Easy Twitter Bootstrap for ASP.Net MVC 4

Package Homepage:
  https://github.com/erichexter/twitter.bootstrap.mvc

Twitter Bootstrap Homepage:
  http://twitter.github.com/bootstrap/

See the introduction blog post http://lostechies.com/erichexter/2012/11/20/twitter-bootstrap-mvc4-the-template-nuget-package-for-asp-net-mvc4-projects/

Warning: After installing the package, you may get build errors.
  Compiling transformation: The type or namespace name 'Web' does not exist in the namespace 'Microsoft.VisualStudio' (are you missing an assembly reference?)
  Compiling transformation: The type or namespace name 'MvcTextTemplateHost' could not be found (are you missing a using directive or an assembly reference?)

To resolve these build errors simply close and reopen the solution